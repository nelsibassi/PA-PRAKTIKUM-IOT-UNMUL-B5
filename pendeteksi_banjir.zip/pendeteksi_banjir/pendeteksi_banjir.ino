#define BLYNK_TEMPLATE_ID "TMPL6mMUrT0kw"
#define BLYNK_TEMPLATE_NAME "Pendeteksi Banjir"
#define BLYNK_AUTH_TOKEN "Lpk7ZEjHKOJVZHyfVk5Dje_YeWXMc09H"

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <BlynkSimpleEsp32.h>
#include <UniversalTelegramBot.h>
#include <ArduinoJson.h>

char ssid[] = "iyam";
char pass[] = "aurelcantik";

// Telegram
#define BOT_TOKEN "8901344237:AAFsgF7Huxot_Zu8JupDaIT3L74FMQBWn6o"
#define CHAT_ID "1320043079"

WiFiClientSecure client;
UniversalTelegramBot bot(BOT_TOKEN, client);

// Pin Sensor
#define rainPin 32
#define waterPin 35

BlynkTimer timer;

bool rainNotif = false;
bool warningNotif = false;
bool dangerNotif = false;

void sendSensor()
{
  int rainValue = analogRead(rainPin);
  int waterValue = analogRead(waterPin);

  Serial.print("Rain: ");
  Serial.println(rainValue);

  Serial.print("Water: ");
  Serial.println(waterValue);

  // Kirim ke Blynk
  Blynk.virtualWrite(V0, rainValue);
  Blynk.virtualWrite(V1, waterValue);

  // =========================
  // DETEKSI HUJAN
  // =========================

  if (rainValue < 2000)
  {
    if (!rainNotif)
    {
      bot.sendMessage(CHAT_ID,
      "🌧️ Hujan terdeteksi",
      "");

      rainNotif = true;
    }
  }
  else
  {
    rainNotif = false;
  }

  // =========================
  // LEVEL AIR
  // =========================

  // AMAN
  if (waterValue < 1000)
  {
    Blynk.virtualWrite(V2, "AMAN");

    warningNotif = false;
    dangerNotif = false;
  }

  // WASPADA
  else if (waterValue >= 1000 && waterValue <= 2500)
  {
    Blynk.virtualWrite(V2, "WASPADA");

    if (!warningNotif)
    {
      bot.sendMessage(CHAT_ID,
      "⚠️ Air mulai naik (WASPADA)",
      "");

      warningNotif = true;
    }
  }

  // BAHAYA
  else
  {
    Blynk.virtualWrite(V2, "BAHAYA BANJIR");

    if (!dangerNotif)
    {
      bot.sendMessage(CHAT_ID,
      "🚨 BAHAYA BANJIR!",
      "");

      dangerNotif = true;
    }
  }
}

void setup()
{
  Serial.begin(115200);

  WiFi.begin(ssid, pass);

  while (WiFi.status() != WL_CONNECTED)
  {
    delay(1000);
    Serial.println("Connecting WiFi...");
  }

  Serial.println("WiFi Connected");

  client.setInsecure();

  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);

  timer.setInterval(2000L, sendSensor);
}

void loop()
{
  Blynk.run();
  timer.run();
}